# chatajax
Chat PHP MYSQL AJAX

Este chat ha sido creado con el fin de enseñar conceptos basicos de programacion
en php, mysql, ajax, jquery

Chat creado mediante video tutorial en youtube

Chat:
https://www.youtube.com/watch?v=SID4-LMbpqk

Canal:
https://www.youtube.com/AnySlehider
