<?php
$mysql_host = "localhost";
$mysql_user = "root";
$mysql_pass = "";
$mysql_db = "chat";
?>